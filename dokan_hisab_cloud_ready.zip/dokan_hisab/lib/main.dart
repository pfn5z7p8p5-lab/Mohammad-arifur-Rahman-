import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const DokanHisabApp());

class Product {
  String name, category;
  double price;
  int stock;
  Product({required this.name, required this.category, required this.price, this.stock = 0});
  Map<String, dynamic> toJson() => {'name': name, 'category': category, 'price': price, 'stock': stock};
  factory Product.fromJson(Map<String, dynamic> j) => Product(name: j['name'], category: j['category'], price: (j['price'] as num).toDouble(), stock: j['stock'] ?? 0);
}

class DokanHisabApp extends StatefulWidget {
  const DokanHisabApp({super.key});
  @override State<DokanHisabApp> createState() => _DokanHisabAppState();
}

class _DokanHisabAppState extends State<DokanHisabApp> {
  int tab = 0;
  final List<Product> products = [
    Product(name:'Vim 1L', category:'ডিশওয়াশ', price:220, stock:10),
    Product(name:'Vim 210g', category:'ডিশওয়াশ', price:40, stock:25),
    Product(name:'Sepnil 1L', category:'ক্লিনার', price:320, stock:8),
    Product(name:'Naptholin 1kg', category:'ক্লিনার', price:345, stock:5),
    Product(name:'UPL', category:'অন্যান্য', price:185, stock:6),
    Product(name:'Lux B', category:'সাবান', price:80, stock:15),
    Product(name:'Lux 100g', category:'সাবান', price:55, stock:20),
    Product(name:'Margo সাবান', category:'সাবান', price:75, stock:20),
    Product(name:'Dip 1kg', category:'ডিশওয়াশ', price:890, stock:4),
    Product(name:'Dip 500g', category:'ডিশওয়াশ', price:450, stock:7),
    Product(name:'Fay S', category:'ডিশওয়াশ', price:295, stock:5),
    Product(name:'Finis Booster', category:'অন্যান্য', price:45, stock:10),
    Product(name:'Mini Sunsilk', category:'শ্যাম্পু', price:32, stock:12),
    Product(name:'Mini Dove', category:'শ্যাম্পু', price:42, stock:10),
    Product(name:'Mini Clear Men', category:'শ্যাম্পু', price:52, stock:10),
    Product(name:'Sav পানি 5L', category:'পানি/লিকুইড', price:1090, stock:3),
    Product(name:'Sav HW 5L', category:'পানি/লিকুইড', price:955, stock:4),
    Product(name:'Sepnil পানি 5L', category:'পানি/লিকুইড', price:940, stock:4),
    Product(name:'Dettol পানি 5L', category:'পানি/লিকুইড', price:1400, stock:2),
    Product(name:'Max Fresh', category:'অন্যান্য', price:170, stock:8),
    Product(name:'Sav R', category:'ক্লিনার', price:65, stock:10),
    Product(name:'Clear R', category:'ক্লিনার', price:60, stock:10),
    Product(name:'Fixol 1L', category:'ক্লিনার', price:70, stock:7),
    Product(name:'Sav 1L', category:'ক্লিনার', price:240, stock:6),
    Product(name:'Good Night R', category:'অন্যান্য', price:105, stock:8),
    Product(name:'Good Night Machine', category:'অন্যান্য', price:165, stock:5),
    Product(name:'Black Bic', category:'অন্যান্য', price:40, stock:15),
    Product(name:'M.Box', category:'অন্যান্য', price:65, stock:10),
    Product(name:'Vixol BD', category:'ক্লিনার', price:60, stock:7),
    Product(name:'Orchid Hanger', category:'অন্যান্য', price:60, stock:8),
    Product(name:'Orchid', category:'অন্যান্য', price:45, stock:8),
    Product(name:'Butter 1kg', category:'খাবার', price:1790, stock:2),
    Product(name:'Lifebuoy HW 1L', category:'সাবান', price:310, stock:12),
    Product(name:'S Cosco 1D', category:'অন্যান্য', price:150, stock:6),
    Product(name:'Pozzy Wet Tissue', category:'টিস্যু', price:150, stock:10),
    Product(name:'Surf 500g', category:'ডিটারজেন্ট', price:105, stock:12),
    Product(name:'B Hand Towel ছোট', category:'তোয়ালে', price:35, stock:10),
    Product(name:'B Hand Towel', category:'তোয়ালে', price:90, stock:8),
    Product(name:'Pertex Hand Towel', category:'তোয়ালে', price:80, stock:8),
    Product(name:'1D সাদা টয়লেট', category:'টয়লেট ক্লিনার', price:220, stock:8),
    Product(name:'Lizol 1L', category:'ক্লিনার', price:240, stock:7),
    Product(name:'Dettol R', category:'ক্লিনার', price:75, stock:10),
  ];
  final sales = <Map<String,dynamic>>[];

  @override void initState(){super.initState(); _load();}
  Future<void> _load() async { final p=await SharedPreferences.getInstance(); final raw=p.getString('products'); if(raw!=null){setState(()=>products..clear()..addAll((jsonDecode(raw) as List).map((e)=>Product.fromJson(e))));} }
  Future<void> _save() async { final p=await SharedPreferences.getInstance(); await p.setString('products', jsonEncode(products.map((e)=>e.toJson()).toList())); }

  double get stockValue => products.fold(0, (s,p)=>s+p.price*p.stock);
  double get todaySales => sales.fold(0, (s,e)=>s+(e['total'] as double));

  void addProduct(){
    final name=TextEditingController(), price=TextEditingController(), stock=TextEditingController(); String cat='অন্যান্য';
    showDialog(context:context,builder:(_)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:const Text('পণ্য যোগ করুন'),content:SingleChildScrollView(child:Column(children:[TextField(controller:name,decoration:const InputDecoration(labelText:'পণ্যের নাম')),TextField(controller:price,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'দাম (৳)')),TextField(controller:stock,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'স্টক')),DropdownButtonFormField<String>(value:cat,items:['সাবান','ডিশওয়াশ','ক্লিনার','টয়লেট ক্লিনার','শ্যাম্পু','ডিটারজেন্ট','পানি/লিকুইড','টিস্যু','তোয়ালে','খাবার','অন্যান্য'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setD(()=>cat=v!),decoration:const InputDecoration(labelText:'ক্যাটাগরি'))])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('বাতিল')),ElevatedButton(onPressed:(){if(name.text.trim().isEmpty||price.text.isEmpty)return;setState(()=>products.insert(0,Product(name:name.text.trim(),category:cat,price:double.tryParse(price.text)??0,stock:int.tryParse(stock.text)??0)));_save();Navigator.pop(c);},child:const Text('সংরক্ষণ'))])));
  }

  void sell(Product p){int qty=1; final q=TextEditingController(text:'1'); showDialog(context:context,builder:(_)=>AlertDialog(title:Text('${p.name} বিক্রি'),content:TextField(controller:q,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'পরিমাণ')),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('বাতিল')),ElevatedButton(onPressed:(){qty=int.tryParse(q.text)??1;if(qty<1||qty>p.stock)return;setState((){p.stock-=qty;sales.add({'name':p.name,'qty':qty,'total':p.price*qty});});_save();Navigator.pop(context);},child:const Text('বিক্রি করুন'))]));}

  @override Widget build(BuildContext context){
    return MaterialApp(debugShowCheckedModeBanner:false,theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xff08764f)),useMaterial3:true,fontFamily:'sans'),home:Scaffold(appBar:AppBar(title:Text(['ড্যাশবোর্ড','পণ্য','বিক্রি','স্টক','রিপোর্ট'][tab]),actions:[if(tab==1)IconButton(onPressed:addProduct,icon:const Icon(Icons.add))]),body:_body(),bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),label:'হোম'),NavigationDestination(icon:Icon(Icons.inventory_2_outlined),label:'পণ্য'),NavigationDestination(icon:Icon(Icons.point_of_sale_outlined),label:'বিক্রি'),NavigationDestination(icon:Icon(Icons.warehouse_outlined),label:'স্টক'),NavigationDestination(icon:Icon(Icons.bar_chart_outlined),label:'রিপোর্ট')]));
  }
  Widget _body()=>[dashboard(),productList(),salesPage(),stockPage(),reportPage()][tab];
  Widget dashboard()=>ListView(padding:const EdgeInsets.all(16),children:[const Text('আসসালামু আলাইকুম',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:16),Wrap(spacing:10,runSpacing:10,children:[card('মোট পণ্য','${products.length}'),card('স্টক মূল্য','৳ ${stockValue.toStringAsFixed(0)}'),card('আজকের বিক্রি','৳ ${todaySales.toStringAsFixed(0)}'),card('কম স্টক','${products.where((p)=>p.stock<=5).length}')]),const SizedBox(height:20),const Text('দ্রুত কাজ',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:10),Row(children:[Expanded(child:action('পণ্য যোগ',Icons.add_box,addProduct)),const SizedBox(width:10),Expanded(child:action('বিক্রি',Icons.shopping_cart,()=>setState(()=>tab=2)))])]);
  Widget card(String a,String b)=>Container(width:MediaQuery.of(context).size.width/2-22,padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.green.withOpacity(.08),borderRadius:BorderRadius.circular(16)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a),const SizedBox(height:8),Text(b,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold))]);
  Widget action(String t,IconData i,VoidCallback f)=>FilledButton.tonalIcon(onPressed:f,icon:Icon(i),label:Text(t),style:FilledButton.styleFrom(padding:const EdgeInsets.all(18)));
  Widget productList(){return Column(children:[Padding(padding:const EdgeInsets.all(12),child:TextField(onChanged:(v)=>setState((){}),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'পণ্য খুঁজুন...',border:OutlineInputBorder()))),Expanded(child:ListView.builder(itemCount:products.length,itemBuilder:(c,i){final p=products[i];return ListTile(leading:CircleAvatar(child:Text(p.name[0])),title:Text(p.name),subtitle:Text('${p.category} • ৳ ${p.price.toStringAsFixed(0)}'),trailing:IconButton(icon:const Icon(Icons.add_shopping_cart),onPressed:()=>sell(p));}))]);}
  Widget salesPage()=>ListView(padding:const EdgeInsets.all(16),children:[const Text('দ্রুত বিক্রি',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:10),...products.take(12).map((p)=>Card(child:ListTile(title:Text(p.name),subtitle:Text('৳ ${p.price.toStringAsFixed(0)} • স্টক ${p.stock}'),trailing:FilledButton(onPressed:p.stock>0?()=>sell(p):null,child:const Text('বিক্রি')))))]);
  Widget stockPage()=>ListView(children:products.map((p)=>ListTile(title:Text(p.name),subtitle:Text(p.category),trailing:Text('${p.stock}',style:TextStyle(fontWeight:FontWeight.bold,color:p.stock<=5?Colors.red:Colors.green))).toList());
  Widget reportPage()=>ListView(padding:const EdgeInsets.all(16),children:[Text('আজকের বিক্রি',style:Theme.of(context).textTheme.titleLarge),Text('৳ ${todaySales.toStringAsFixed(0)}',style:const TextStyle(fontSize:32,fontWeight:FontWeight.bold)),const SizedBox(height:20),Text('স্টকের মোট মূল্য',style:Theme.of(context).textTheme.titleLarge),Text('৳ ${stockValue.toStringAsFixed(0)}',style:const TextStyle(fontSize:32,fontWeight:FontWeight.bold)),const SizedBox(height:20),Text('আজকের বিক্রির সংখ্যা: ${sales.length}')]);
}
