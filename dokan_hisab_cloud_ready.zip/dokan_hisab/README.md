# দোকান হিসাব — iOS + Android

Flutter starter app for product, sales, stock and reports. Bengali UI and the supplied product list are included.

## Run
1. Install Flutter SDK.
2. In this folder run `flutter pub get`.
3. Android: `flutter run` with an Android device/emulator.
4. iOS: `flutter run` on macOS with Xcode and an iPhone simulator/device.

The app stores products locally using SharedPreferences.
