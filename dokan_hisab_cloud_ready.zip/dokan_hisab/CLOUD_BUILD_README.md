দোকান হিসাব — Mac ছাড়া Cloud Build

এই project-এ codemagic.yaml দেওয়া আছে।
1) GitHub-এ পুরো dokan_hisab folder upload করো।
2) Codemagic-এ GitHub connect করে repository select করো।
3) ios_unsigned_preview workflow চালালে iOS Simulator .app artifact তৈরি হবে।
4) Android workflow চালালে APK তৈরি হবে।

বাস্তব iPhone-এ TestFlight দিতে হলে Apple Developer/App Store Connect signing লাগবে।
Codemagic cloud Mac-এ iOS build করে; তোমার নিজের Mac দরকার নেই।
